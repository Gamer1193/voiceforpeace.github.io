import { 
  Heart, 
  BookOpen, 
  Users, 
  TreePine, 
  GraduationCap,
  Handshake,
  Globe,
  Target,
  Award,
  CheckCircle,
  Lightbulb,
  Shield,
  Star,
  TrendingUp,
  Calendar,
  MapPin,
  Clock,
  User
} from 'lucide-react';

export const STATS = [
  { icon: Users, label: 'Lives Impacted', value: '250K+', color: 'text-blue-600' },
  { icon: Globe, label: 'Countries', value: '75+', color: 'text-green-600' },
  { icon: Award, label: 'Awards', value: '25+', color: 'text-purple-600' },
  { icon: Target, label: 'Success Rate', value: '96%', color: 'text-orange-600' }
];

export const FEATURES = [
  {
    icon: Heart,
    title: 'Community Healing',
    description: 'Supporting communities through healing and reconciliation programs.',
    color: 'from-red-100 to-pink-100',
    iconColor: 'text-red-600'
  },
  {
    icon: BookOpen,
    title: 'Peace Education',
    description: 'Educational programs promoting understanding and conflict resolution.',
    color: 'from-blue-100 to-indigo-100',
    iconColor: 'text-blue-600'
  },
  {
    icon: Users,
    title: 'Youth Leadership',
    description: 'Empowering young people to become peace ambassadors.',
    color: 'from-green-100 to-emerald-100',
    iconColor: 'text-green-600'
  },
  {
    icon: TreePine,
    title: 'Environmental Peace',
    description: 'Addressing environmental challenges that contribute to conflict.',
    color: 'from-teal-100 to-cyan-100',
    iconColor: 'text-teal-600'
  }
];

export const VALUES = [
  {
    icon: Heart,
    title: 'Compassion',
    description: 'We approach every situation with empathy and understanding, recognizing the humanity in all people.',
    color: 'from-red-500 to-pink-500'
  },
  {
    icon: Handshake,
    title: 'Unity',
    description: 'We believe that diverse perspectives strengthen our mission and create more effective solutions.',
    color: 'from-blue-500 to-indigo-500'
  },
  {
    icon: Shield,
    title: 'Integrity',
    description: 'We maintain the highest ethical standards in all our actions and remain transparent in our work.',
    color: 'from-green-500 to-emerald-500'
  },
  {
    icon: Lightbulb,
    title: 'Innovation',
    description: 'We continuously seek creative and effective approaches to peacebuilding and conflict resolution.',
    color: 'from-yellow-500 to-orange-500'
  }
];

export const TESTIMONIALS = [
  {
    name: 'Maria Rodriguez',
    role: 'Community Leader',
    content: 'Voice for Peace transformed our community. Their healing programs brought us together after years of division.',
    image: 'https://images.unsplash.com/photo-1494790108755-2616c9653c6d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80'
  },
  {
    name: 'David Chen',
    role: 'Youth Ambassador',
    content: 'The leadership program gave me the tools and confidence to make a real difference in my community.',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80'
  },
  {
    name: 'Amara Johnson',
    role: 'Educator',
    content: 'The peace education curriculum has revolutionized how we teach conflict resolution in our schools.',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80'
  }
];

export const TEAM = [
  {
    name: 'Dr. Sarah Mitchell',
    role: 'Founder & CEO',
    bio: 'Former UN mediator with 20+ years experience in conflict resolution.',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80',
    specialties: ['Conflict Resolution', 'International Relations', 'Policy Development']
  },
  {
    name: 'Marcus Johnson',
    role: 'Director of Programs',
    bio: 'Community organizer and peace educator specializing in youth development.',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80',
    specialties: ['Youth Leadership', 'Community Organizing', 'Program Development']
  },
  {
    name: 'Dr. Amina Hassan',
    role: 'Head of Research',
    bio: 'Peace studies researcher focusing on innovative conflict prevention methods.',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80',
    specialties: ['Peace Research', 'Data Analysis', 'Innovation Strategy']
  },
  {
    name: 'Carlos Rodriguez',
    role: 'Regional Director',
    bio: 'Former diplomat with expertise in Latin American peace processes.',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80',
    specialties: ['Diplomacy', 'Regional Development', 'Cultural Mediation']
  }
];

export const VOLUNTEER_OPPORTUNITIES = [
  {
    id: 1,
    title: 'Peace Education Facilitator',
    description: 'Lead workshops and training sessions on conflict resolution and peace education.',
    location: 'Remote/Various Locations',
    timeCommitment: '5-10 hours/week',
    skills: ['Public Speaking', 'Education', 'Conflict Resolution'],
    urgency: 'High'
  },
  {
    id: 2,
    title: 'Community Outreach Coordinator',
    description: 'Build relationships with local communities and organizations to expand our reach.',
    location: 'Regional Offices',
    timeCommitment: '10-15 hours/week',
    skills: ['Communication', 'Networking', 'Project Management'],
    urgency: 'Medium'
  },
  {
    id: 3,
    title: 'Digital Content Creator',
    description: 'Create engaging content for social media, blog posts, and educational materials.',
    location: 'Remote',
    timeCommitment: '3-8 hours/week',
    skills: ['Writing', 'Graphic Design', 'Social Media'],
    urgency: 'Medium'
  }
];

export const BLOG_POSTS = [
  {
    id: 1,
    title: 'The Role of Youth in Modern Peacebuilding',
    excerpt: 'Exploring how young people are leading innovative approaches to conflict resolution and community healing.',
    author: 'Dr. Sarah Mitchell',
    date: 'March 10, 2024',
    readTime: '5 min read',
    category: 'Youth Leadership',
    image: 'https://images.unsplash.com/photo-1529390079861-591de354faf5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    featured: true
  },
  {
    id: 2,
    title: 'Technology for Peace: AI in Conflict Prevention',
    excerpt: 'How artificial intelligence and digital platforms are revolutionizing early warning systems for conflicts.',
    author: 'Marcus Johnson',
    date: 'March 8, 2024',
    readTime: '7 min read',
    category: 'Technology',
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    featured: false
  },
  {
    id: 3,
    title: 'Environmental Justice as a Path to Peace',
    excerpt: 'Understanding the connection between environmental degradation and conflict, and solutions for sustainable peace.',
    author: 'Dr. Amina Hassan',
    date: 'March 5, 2024',
    readTime: '6 min read',
    category: 'Environment',
    image: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    featured: false
  }
];

export const EVENTS = [
  {
    id: 1,
    title: 'Global Peace Summit 2024',
    description: 'Annual gathering of peace leaders, policymakers, and advocates from around the world.',
    date: 'March 15-17, 2024',
    time: '9:00 AM - 6:00 PM',
    location: 'Geneva, Switzerland',
    type: 'Conference',
    attendees: '500+ expected',
    featured: true
  },
  {
    id: 2,
    title: 'Youth Peace Ambassador Training',
    description: 'Intensive training program for young peace advocates aged 18-25.',
    date: 'April 22-24, 2024',
    time: '10:00 AM - 4:00 PM',
    location: 'Virtual Event',
    type: 'Training',
    attendees: '200+ participants',
    featured: false
  },
  {
    id: 3,
    title: 'Community Healing Workshop',
    description: 'Learn practical skills for facilitating healing and reconciliation in communities.',
    date: 'May 8-9, 2024',
    time: '9:00 AM - 5:00 PM',
    location: 'Nairobi, Kenya',
    type: 'Workshop',
    attendees: '150+ participants',
    featured: true
  }
];