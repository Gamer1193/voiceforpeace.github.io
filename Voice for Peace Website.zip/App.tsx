import { useState } from 'react';
import EnhancedHeader from './components/EnhancedHeader';
import Footer from './components/Footer';
import Router, { PageType } from './components/Router';
import ChatBot from './components/ChatBot';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('home');

  const handleNavigate = (page: PageType) => {
    setCurrentPage(page);
  };

  return (
    <div className="min-h-screen">
      <EnhancedHeader currentPage={currentPage} onNavigate={handleNavigate} />
      <main>
        <Router currentPage={currentPage} setCurrentPage={setCurrentPage} />
      </main>
      <Footer />
      <ChatBot onNavigate={handleNavigate} />
    </div>
  );
}