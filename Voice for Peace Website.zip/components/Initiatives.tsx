import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { 
  Heart, 
  BookOpen, 
  Handshake, 
  TreePine, 
  Users, 
  GraduationCap,
  ArrowRight
} from 'lucide-react';

export default function Initiatives() {
  const initiatives = [
    {
      id: 1,
      icon: Heart,
      title: 'Community Healing',
      description: 'Supporting communities affected by conflict through counseling, mediation, and reconciliation programs.',
      impact: '15,000+ lives touched',
      color: 'from-red-100 to-pink-100',
      iconColor: 'text-red-600'
    },
    {
      id: 2,
      icon: BookOpen,
      title: 'Peace Education',
      description: 'Developing educational curricula that promote understanding, empathy, and conflict resolution skills.',
      impact: '200+ schools engaged',
      color: 'from-blue-100 to-indigo-100',
      iconColor: 'text-blue-600'
    },
    {
      id: 3,
      icon: Handshake,
      title: 'Dialogue Facilitation',
      description: 'Creating safe spaces for meaningful conversations between different communities and stakeholders.',
      impact: '500+ dialogues hosted',
      color: 'from-green-100 to-emerald-100',
      iconColor: 'text-green-600'
    },
    {
      id: 4,
      icon: TreePine,
      title: 'Environmental Peace',
      description: 'Addressing environmental challenges that contribute to conflict through sustainable community projects.',
      impact: '50+ projects launched',
      color: 'from-teal-100 to-cyan-100',
      iconColor: 'text-teal-600'
    },
    {
      id: 5,
      icon: Users,
      title: 'Youth Leadership',
      description: 'Empowering young people to become peace ambassadors and leaders in their communities.',
      impact: '1,000+ youth trained',
      color: 'from-purple-100 to-violet-100',
      iconColor: 'text-purple-600'
    },
    {
      id: 6,
      icon: GraduationCap,
      title: 'Skills Development',
      description: 'Providing vocational training and economic opportunities to build resilient, peaceful communities.',
      impact: '2,500+ people trained',
      color: 'from-orange-100 to-amber-100',
      iconColor: 'text-orange-600'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.2,
        staggerChildren: 0.1
      }
    }
  };

  const cardVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <section id="initiatives" className="py-20 bg-gradient-to-b from-white to-[color:var(--peace-blue-50)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
            Our Peace{' '}
            <span className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-800)] bg-clip-text text-transparent">
              Initiatives
            </span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Discover the various ways we're working to create positive change and build lasting peace in communities around the world.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {initiatives.map((initiative, index) => {
            const Icon = initiative.icon;
            return (
              <motion.div
                key={initiative.id}
                variants={cardVariants}
                whileHover={{ 
                  scale: 1.05, 
                  y: -10,
                  transition: { duration: 0.3, ease: "easeOut" }
                }}
                className="group"
              >
                <Card className="h-full border-0 shadow-lg hover:shadow-2xl transition-all duration-300 bg-white/80 backdrop-blur-sm overflow-hidden">
                  <CardHeader className="pb-4">
                    <div className={`w-16 h-16 bg-gradient-to-br ${initiative.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className={`w-8 h-8 ${initiative.iconColor}`} />
                    </div>
                    <CardTitle className="text-xl font-bold text-slate-900 group-hover:text-[color:var(--peace-blue-700)] transition-colors duration-300">
                      {initiative.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <CardDescription className="text-slate-600 mb-4 leading-relaxed">
                      {initiative.description}
                    </CardDescription>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-semibold text-[color:var(--peace-blue-600)] bg-[color:var(--peace-blue-100)] px-3 py-1 rounded-full">
                        {initiative.impact}
                      </div>
                      <motion.div
                        whileHover={{ x: 5 }}
                        transition={{ duration: 0.2 }}
                      >
                        <ArrowRight className="w-5 h-5 text-slate-400 group-hover:text-[color:var(--peace-blue-600)] transition-colors duration-300" />
                      </motion.div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <Button 
            size="lg" 
            variant="outline"
            className="border-[color:var(--peace-blue-600)] text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)] px-8 py-4 rounded-full"
          >
            <a href="#contact" className="flex items-center space-x-2">
              <span>Learn About All Our Initiatives</span>
              <ArrowRight className="w-5 h-5" />
            </a>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}