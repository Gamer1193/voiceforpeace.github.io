import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { X, Send, MessageCircle, Bot } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Message {
  id: number;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

interface ChatBotProps {
  onNavigate?: (page: string) => void;
}

export default function ChatBot({ onNavigate }: ChatBotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hi there! 👋 I'm zen, your friendly Voice for Peace assistant. How can I help you today?",
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getBotResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    // Peace and mission related
    if (message.includes('peace') || message.includes('mission')) {
      return "Our mission is to promote peace and understanding worldwide! 🕊️ We believe in creating a more harmonious world through education, dialogue, and community action. Would you like to know about our specific programs?";
    }
    
    // Programs
    if (message.includes('program') || message.includes('initiative')) {
      return "We have several amazing programs! 🌟 Including Peace Education, Community Dialogue, Youth Leadership, and Conflict Resolution. Which one interests you most?";
    }
    
    // Events
    if (message.includes('event') || message.includes('workshop')) {
      return "We host regular events including workshops, peace circles, and community gatherings! 📅 Check out our Events page to see what's coming up. Would you like me to take you there?";
    }
    
    // Volunteer
    if (message.includes('volunteer') || message.includes('help') || message.includes('join')) {
      return "That's wonderful that you want to get involved! 🤝 We're always looking for passionate volunteers. You can join our team in various ways - from event organizing to peace education. Visit our Volunteer page for more details!";
    }
    
    // About
    if (message.includes('about') || message.includes('who') || message.includes('what')) {
      return "Voice for Peace is a community-driven organization dedicated to fostering understanding and promoting peaceful solutions to conflicts. ✨ We work through education, dialogue, and community engagement. Want to learn more about our story?";
    }
    
    // Resources
    if (message.includes('resource') || message.includes('learn') || message.includes('education')) {
      return "We have extensive resources for peace education! 📚 Including guides, articles, toolkits, and educational materials. Check out our Resources page for comprehensive learning materials.";
    }
    
    // Contact
    if (message.includes('contact') || message.includes('reach') || message.includes('talk')) {
      return "I'd love to help you get in touch! 💬 You can reach our team through our Contact page, or I can help answer questions right here. What would you like to know?";
    }
    
    // Navigation help
    if (message.includes('navigate') || message.includes('find') || message.includes('page')) {
      return "I can help you navigate our website! 🧭 We have pages for Home, About, Programs, Events, Blog, Volunteer, Resources, and Contact. Which section would you like to visit?";
    }
    
    // Greetings
    if (message.includes('hello') || message.includes('hi') || message.includes('hey')) {
      return "Hello! 😊 It's great to meet you! I'm here to help you learn about Voice for Peace and find what you're looking for. What can I assist you with today?";
    }
    
    // Thanks
    if (message.includes('thank') || message.includes('thanks')) {
      return "You're very welcome! 🙏 I'm always happy to help spread the message of peace. Is there anything else you'd like to know about our organization?";
    }
    
    // Default responses
    const defaultResponses = [
      "That's an interesting question! 🤔 I'd love to help you learn more about our peace initiatives. What specific aspect interests you most?",
      "I'm here to help with any questions about Voice for Peace! 💙 Feel free to ask about our programs, events, volunteer opportunities, or how to get involved.",
      "Great question! 🌟 Our organization focuses on building bridges and promoting understanding. Would you like to know more about how we work toward peace?",
      "I'm always excited to talk about peace and our mission! ✨ What would you like to explore - our programs, upcoming events, or ways to get involved?"
    ];
    
    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now(),
      text: inputText,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const botResponse: Message = {
        id: Date.now() + 1,
        text: getBotResponse(inputText),
        isBot: true,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Floating Chat Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 20 }}
      >
        <Button
          onClick={() => setIsOpen(true)}
          className={`h-14 w-14 rounded-full shadow-3d shadow-3d-hover bg-gradient-to-br from-peace-blue-500 to-peace-blue-700 hover:from-peace-blue-600 hover:to-peace-blue-800 transition-all duration-300 ${
            isOpen ? 'hidden' : 'flex'
          }`}
        >
          <MessageCircle className="h-6 w-6 animate-bounce-3d" />
        </Button>
      </motion.div>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className="fixed bottom-6 right-6 z-50 w-80 h-96 md:w-96 md:h-[500px]"
          >
            <Card className="h-full flex flex-col shadow-3d glass-morphism border-peace-blue-200">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-peace-blue-100 bg-gradient-to-r from-peace-blue-50 to-white">
                <div className="flex items-center gap-3">
                  <motion.div
                    className="h-10 w-10 bg-gradient-to-br from-peace-blue-500 to-peace-blue-700 rounded-full flex items-center justify-center"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  >
                    <Bot className="h-5 w-5 text-white" />
                  </motion.div>
                  <div>
                    <h3 className="font-semibold text-peace-blue-800">zen</h3>
                    <p className="text-xs text-peace-blue-600">Peace Assistant</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsOpen(false)}
                  className="h-8 w-8 p-0 text-peace-blue-600 hover:bg-peace-blue-100"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
                  >
                    <div
                      className={`max-w-[80%] p-3 rounded-lg shadow-sm ${
                        message.isBot
                          ? 'bg-peace-blue-50 text-peace-blue-900 border border-peace-blue-100'
                          : 'bg-peace-blue-600 text-white'
                      }`}
                    >
                      <p className="text-sm">{message.text}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </motion.div>
                ))}
                
                {/* Typing Indicator */}
                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex justify-start"
                  >
                    <div className="bg-peace-blue-50 p-3 rounded-lg border border-peace-blue-100">
                      <div className="flex space-x-1">
                        <motion.div
                          className="w-2 h-2 bg-peace-blue-400 rounded-full"
                          animate={{ y: [-2, 2, -2] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0 }}
                        />
                        <motion.div
                          className="w-2 h-2 bg-peace-blue-400 rounded-full"
                          animate={{ y: [-2, 2, -2] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }}
                        />
                        <motion.div
                          className="w-2 h-2 bg-peace-blue-400 rounded-full"
                          animate={{ y: [-2, 2, -2] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }}
                        />
                      </div>
                    </div>
                  </motion.div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="p-4 border-t border-peace-blue-100">
                <div className="flex gap-2">
                  <Input
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type your message..."
                    className="flex-1 border-peace-blue-200 focus:border-peace-blue-400 focus:ring-peace-blue-400"
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={!inputText.trim() || isTyping}
                    size="sm"
                    className="bg-peace-blue-600 hover:bg-peace-blue-700 text-white"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}