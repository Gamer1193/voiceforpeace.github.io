import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Heart, 
  Users, 
  GraduationCap, 
  Handshake, 
  TreePine, 
  BookOpen,
  DollarSign,
  Target,
  TrendingUp,
  Award,
  Globe,
  ArrowRight
} from 'lucide-react';

export default function About() {
  const programs = [
    {
      id: 1,
      title: 'Peace Education Initiative',
      description: 'Comprehensive educational programs designed to teach conflict resolution, empathy, and peaceful communication in schools and communities worldwide.',
      image: 'https://images.unsplash.com/photo-1544717297-fa95b6ee9643?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      impact: '250+ schools reached',
      participants: '15,000+ students',
      icon: BookOpen,
      details: [
        'Curriculum development for peace education',
        'Teacher training programs',
        'Student leadership workshops',
        'Community dialogue sessions'
      ]
    },
    {
      id: 2,
      title: 'Community Healing Centers',
      description: 'Safe spaces where communities affected by conflict can come together for healing, reconciliation, and building sustainable peace through dialogue and support.',
      image: 'https://images.unsplash.com/photo-1559027615-cd4628902d4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      impact: '45 centers established',
      participants: '8,500+ people served',
      icon: Heart,
      details: [
        'Trauma counseling services',
        'Mediation and reconciliation',
        'Community support groups',
        'Cultural healing ceremonies'
      ]
    },
    {
      id: 3,
      title: 'Youth Leadership Program',
      description: 'Empowering the next generation of peace leaders through mentorship, training, and opportunities to lead positive change in their communities.',
      image: 'https://images.unsplash.com/photo-1529390079861-591de354faf5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      impact: '1,200+ youth trained',
      participants: '50+ youth ambassadors',
      icon: Users,
      details: [
        'Leadership skills development',
        'Peace advocacy training',
        'Mentorship programs',
        'Youth-led community projects'
      ]
    },
    {
      id: 4,
      title: 'Environmental Peacebuilding',
      description: 'Addressing environmental challenges that contribute to conflict while promoting sustainable practices that bring communities together.',
      image: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      impact: '75+ projects completed',
      participants: '25,000+ beneficiaries',
      icon: TreePine,
      details: [
        'Sustainable agriculture programs',
        'Water resource management',
        'Renewable energy initiatives',
        'Environmental conflict resolution'
      ]
    }
  ];

  const donationGoals = [
    {
      title: 'Education Programs',
      current: 75000,
      goal: 100000,
      description: 'Fund peace education in 50 new schools',
      icon: GraduationCap
    },
    {
      title: 'Community Centers',
      current: 120000,
      goal: 150000,
      description: 'Establish 10 new healing centers',
      icon: Heart
    },
    {
      title: 'Youth Leadership',
      current: 45000,
      goal: 60000,
      description: 'Train 500 new youth ambassadors',
      icon: Users
    }
  ];

  const impactStats = [
    { icon: Target, label: 'Lives Impacted', value: '150K+', color: 'text-green-600' },
    { icon: Globe, label: 'Countries', value: '45', color: 'text-blue-600' },
    { icon: Award, label: 'Awards Received', value: '12', color: 'text-purple-600' },
    { icon: TrendingUp, label: 'Success Rate', value: '94%', color: 'text-orange-600' }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-b from-white to-[color:var(--peace-blue-50)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
            Our{' '}
            <span className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-800)] bg-clip-text text-transparent">
              Impact
            </span>{' '}
            in Action
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Through dedicated programs and community partnerships, we're building lasting peace and creating positive change worldwide.
          </p>
        </motion.div>

        {/* Impact Statistics */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20"
        >
          {impactStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                whileHover={{ scale: 1.05, y: -5 }}
                className="text-center bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-[color:var(--peace-blue-200)]"
              >
                <div className="flex items-center justify-center w-12 h-12 bg-[color:var(--peace-blue-100)] rounded-full mb-4 mx-auto">
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
                <div className="text-2xl font-bold text-slate-900 mb-1">{stat.value}</div>
                <div className="text-sm text-slate-600">{stat.label}</div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Community Programs */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-slate-900 mb-4">Community Programs</h3>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Our comprehensive programs address the root causes of conflict while building sustainable peace from the ground up.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {programs.map((program, index) => {
              const Icon = program.icon;
              return (
                <motion.div
                  key={program.id}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.02 }}
                  className="group"
                >
                  <Card className="h-full border-0 shadow-xl hover:shadow-2xl transition-all duration-300 bg-white/90 backdrop-blur-sm overflow-hidden">
                    <div className="relative h-48 overflow-hidden">
                      <ImageWithFallback
                        src={program.image}
                        alt={program.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute top-4 right-4 w-12 h-12 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center">
                        <Icon className="w-6 h-6 text-[color:var(--peace-blue-600)]" />
                      </div>
                    </div>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-xl font-bold text-slate-900 group-hover:text-[color:var(--peace-blue-700)] transition-colors duration-300">
                        {program.title}
                      </CardTitle>
                      <CardDescription className="text-slate-600 leading-relaxed">
                        {program.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="grid grid-cols-2 gap-4 mb-6">
                        <div className="bg-[color:var(--peace-blue-50)] rounded-lg p-3 text-center">
                          <div className="text-lg font-bold text-[color:var(--peace-blue-700)]">{program.impact}</div>
                          <div className="text-xs text-slate-600">Impact</div>
                        </div>
                        <div className="bg-[color:var(--peace-blue-50)] rounded-lg p-3 text-center">
                          <div className="text-lg font-bold text-[color:var(--peace-blue-700)]">{program.participants}</div>
                          <div className="text-xs text-slate-600">Participants</div>
                        </div>
                      </div>
                      <ul className="space-y-2">
                        {program.details.map((detail, detailIndex) => (
                          <li key={detailIndex} className="flex items-center text-sm text-slate-600">
                            <div className="w-2 h-2 bg-[color:var(--peace-blue-400)] rounded-full mr-3 flex-shrink-0" />
                            {detail}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Donations Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] rounded-3xl p-8 md:p-12 text-white"
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">Support Our Mission</h3>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto">
              Your contribution helps us expand our programs and reach more communities in need of healing and peace.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {donationGoals.map((goal, index) => {
              const Icon = goal.icon;
              const percentage = (goal.current / goal.goal) * 100;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.05 }}
                  className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20"
                >
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mr-3">
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <h4 className="font-semibold">{goal.title}</h4>
                  </div>
                  <p className="text-blue-100 text-sm mb-4">{goal.description}</p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>${goal.current.toLocaleString()}</span>
                      <span>${goal.goal.toLocaleString()}</span>
                    </div>
                    <Progress value={percentage} className="h-2 bg-white/20" />
                    <div className="text-right text-sm text-blue-100">{percentage.toFixed(0)}% funded</div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          <div className="text-center">
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  size="lg" 
                  className="bg-white text-[color:var(--peace-blue-600)] hover:bg-blue-50 px-8 py-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  <DollarSign className="w-5 h-5 mr-2" />
                  Donate Now
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-white/30 text-white hover:bg-white/10 px-8 py-4 rounded-full"
                >
                  Learn More About Funding
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </motion.div>
            </div>
            <p className="text-blue-200 text-sm mt-4">
              100% of donations go directly to our programs. We are a registered 501(c)(3) nonprofit organization.
            </p>
          </div>
        </motion.div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 border border-[color:var(--peace-blue-200)] shadow-lg">
            <h3 className="text-2xl font-bold text-slate-900 mb-4">Ready to Make a Difference?</h3>
            <p className="text-slate-600 mb-6 max-w-2xl mx-auto">
              Whether through volunteering, donating, or spreading awareness, there are many ways to support our mission for peace.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button 
                size="lg" 
                className="bg-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-700)] text-white px-8 py-3 rounded-full"
                asChild
              >
                <a href="#join">Join Our Community</a>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-[color:var(--peace-blue-600)] text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)] px-8 py-3 rounded-full"
                asChild
              >
                <a href="#contact">Contact Us</a>
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}