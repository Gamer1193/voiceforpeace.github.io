import { useState } from 'react';
import { motion } from 'motion/react';
import { Menu, X, Heart, ChevronDown } from 'lucide-react';
import { Button } from './ui/button';
import { PageType } from './Router';

interface EnhancedHeaderProps {
  currentPage: PageType;
  onNavigate: (page: PageType) => void;
}

export default function EnhancedHeader({ currentPage, onNavigate }: EnhancedHeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const navItems = [
    { id: 'home', label: 'Home', page: 'home' as PageType },
    { id: 'about', label: 'About', page: 'about' as PageType },
    { 
      id: 'programs', 
      label: 'Programs', 
      page: 'programs' as PageType,
      dropdown: [
        { label: 'Peace Education', page: 'programs' as PageType },
        { label: 'Community Healing', page: 'programs' as PageType },
        { label: 'Youth Leadership', page: 'programs' as PageType },
      ]
    },
    { id: 'events', label: 'Events', page: 'events' as PageType },
    { id: 'blog', label: 'Blog', page: 'blog' as PageType },
    { id: 'volunteer', label: 'Volunteer', page: 'volunteer' as PageType },
    { id: 'resources', label: 'Resources', page: 'resources' as PageType },
    { id: 'contact', label: 'Contact', page: 'contact' as PageType },
  ];

  const handleNavClick = (page: PageType) => {
    onNavigate(page);
    setIsMenuOpen(false);
    setActiveDropdown(null);
  };

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[color:var(--peace-blue-200)] shadow-lg"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            onClick={() => handleNavClick('home')}
            className="flex items-center space-x-3 cursor-pointer"
          >
            <motion.div 
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.6 }}
              className="flex items-center justify-center w-12 h-12 bg-gradient-to-br from-[color:var(--peace-blue-500)] to-[color:var(--peace-blue-600)] rounded-full shadow-lg"
            >
              <Heart className="w-7 h-7 text-white" />
            </motion.div>
            <div>
              <div className="text-2xl font-bold bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-800)] bg-clip-text text-transparent">
                Voice for Peace
              </div>
              <div className="text-xs text-slate-500 -mt-1">Building Better Tomorrow</div>
            </div>
          </motion.div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navItems.map((item, index) => (
              <div key={item.id} className="relative">
                <motion.button
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.6 }}
                  whileHover={{ y: -2 }}
                  onClick={() => item.dropdown ? setActiveDropdown(activeDropdown === item.id ? null : item.id) : handleNavClick(item.page)}
                  className={`flex items-center space-x-1 px-4 py-2 rounded-lg transition-all duration-300 relative group ${
                    currentPage === item.page 
                      ? 'text-[color:var(--peace-blue-600)] bg-[color:var(--peace-blue-50)]' 
                      : 'text-slate-700 hover:text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)]'
                  }`}
                >
                  <span>{item.label}</span>
                  {item.dropdown && <ChevronDown className="w-4 h-4" />}
                  {currentPage === item.page && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute inset-0 bg-[color:var(--peace-blue-100)] rounded-lg -z-10"
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    />
                  )}
                </motion.button>

                {/* Dropdown Menu */}
                {item.dropdown && activeDropdown === item.id && (
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    className="absolute top-full left-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-[color:var(--peace-blue-200)] py-2 z-50"
                  >
                    {item.dropdown.map((dropdownItem, dropdownIndex) => (
                      <motion.button
                        key={dropdownIndex}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: dropdownIndex * 0.1 }}
                        whileHover={{ x: 5, backgroundColor: 'var(--peace-blue-50)' }}
                        onClick={() => handleNavClick(dropdownItem.page)}
                        className="w-full text-left px-4 py-3 text-slate-700 hover:text-[color:var(--peace-blue-600)] transition-colors duration-200"
                      >
                        {dropdownItem.label}
                      </motion.button>
                    ))}
                  </motion.div>
                )}
              </div>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center space-x-4">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button 
                onClick={() => handleNavClick('volunteer')}
                className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] hover:from-[color:var(--peace-blue-700)] hover:to-[color:var(--peace-blue-800)] text-white px-6 py-2 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
              >
                Get Involved
              </Button>
            </motion.div>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-slate-700 hover:text-[color:var(--peace-blue-600)]"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <motion.div
          initial={false}
          animate={{ 
            height: isMenuOpen ? 'auto' : 0, 
            opacity: isMenuOpen ? 1 : 0 
          }}
          transition={{ duration: 0.3, ease: "easeInOut" }}
          className="lg:hidden overflow-hidden"
        >
          <nav className="py-4 space-y-2 border-t border-[color:var(--peace-blue-200)]">
            {navItems.map((item, index) => (
              <motion.button
                key={item.id}
                initial={{ x: -20, opacity: 0 }}
                animate={{ 
                  x: isMenuOpen ? 0 : -20, 
                  opacity: isMenuOpen ? 1 : 0 
                }}
                transition={{ delay: index * 0.1, duration: 0.3 }}
                onClick={() => handleNavClick(item.page)}
                className={`block w-full text-left py-3 px-4 rounded-lg transition-all duration-300 ${
                  currentPage === item.page 
                    ? 'text-[color:var(--peace-blue-600)] bg-[color:var(--peace-blue-50)]' 
                    : 'text-slate-700 hover:text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)]'
                }`}
              >
                {item.label}
              </motion.button>
            ))}
            <motion.div
              initial={{ x: -20, opacity: 0 }}
              animate={{ 
                x: isMenuOpen ? 0 : -20, 
                opacity: isMenuOpen ? 1 : 0 
              }}
              transition={{ delay: navItems.length * 0.1, duration: 0.3 }}
              className="pt-4 border-t border-[color:var(--peace-blue-200)]"
            >
              <Button 
                onClick={() => handleNavClick('volunteer')}
                className="w-full bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white py-3 rounded-lg"
              >
                Get Involved
              </Button>
            </motion.div>
          </nav>
        </motion.div>
      </div>
    </motion.header>
  );
}