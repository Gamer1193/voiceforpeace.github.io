import { motion } from 'motion/react';
import { Button } from './ui/button';
import { ArrowRight, Users, Globe, Sparkles } from 'lucide-react';

export default function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-white via-[color:var(--peace-blue-50)] to-white">
      {/* Background decorations */}
      <div className="absolute inset-0">
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-20 left-10 w-32 h-32 bg-[color:var(--peace-blue-100)] rounded-full opacity-30"
        />
        <motion.div
          animate={{ 
            scale: [1.2, 1, 1.2],
            rotate: [360, 180, 0]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-20 right-10 w-24 h-24 bg-[color:var(--peace-blue-200)] rounded-full opacity-40"
        />
        <motion.div
          animate={{ 
            y: [-20, 20, -20],
            x: [-10, 10, -10]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/2 right-1/4 w-16 h-16 bg-[color:var(--peace-blue-300)] rounded-full opacity-20"
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="text-center"
        >
          <motion.div variants={itemVariants} className="mb-8">
            <motion.div 
              className="inline-flex items-center space-x-2 bg-[color:var(--peace-blue-100)] text-[color:var(--peace-blue-800)] px-6 py-3 rounded-full mb-8"
              whileHover={{ scale: 1.05 }}
            >
              <Sparkles className="w-5 h-5" />
              <span className="text-sm font-medium">Building a Better Tomorrow Together</span>
            </motion.div>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-slate-900 mb-6 leading-tight">
              Together, Our{' '}
              <span className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-800)] bg-clip-text text-transparent">
                Voices
              </span>{' '}
              Can{' '}
              <br className="hidden sm:block" />
              Change the{' '}
              <span className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-800)] bg-clip-text text-transparent">
                World
              </span>
            </h1>
          </motion.div>

          <motion.p variants={itemVariants} className="text-xl text-slate-600 mb-12 max-w-3xl mx-auto leading-relaxed">
            Join a global movement dedicated to fostering peace, understanding, and positive change. 
            Every voice matters, every action counts, and together we can build a more harmonious world.
          </motion.p>

          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-16">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button 
                size="lg" 
                className="bg-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-700)] text-white px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                asChild
              >
                <a href="#join" className="flex items-center space-x-2">
                  <span>Join the Movement</span>
                  <ArrowRight className="w-5 h-5" />
                </a>
              </Button>
            </motion.div>
            
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-[color:var(--peace-blue-600)] text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)] px-8 py-4 text-lg rounded-full"
                asChild
              >
                <a href="#about">Learn More</a>
              </Button>
            </motion.div>
          </motion.div>

          {/* Statistics */}
          <motion.div 
            variants={itemVariants}
            className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto"
          >
            {[
              { icon: Users, label: 'Active Members', value: '50K+' },
              { icon: Globe, label: 'Countries Reached', value: '120+' },
              { icon: Sparkles, label: 'Peace Initiatives', value: '500+' }
            ].map((stat, index) => (
              <motion.div
                key={index}
                whileHover={{ scale: 1.05, y: -5 }}
                className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-[color:var(--peace-blue-200)]"
              >
                <div className="flex items-center justify-center w-12 h-12 bg-[color:var(--peace-blue-100)] rounded-full mb-4 mx-auto">
                  <stat.icon className="w-6 h-6 text-[color:var(--peace-blue-600)]" />
                </div>
                <div className="text-2xl font-bold text-slate-900 mb-2">{stat.value}</div>
                <div className="text-slate-600">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}