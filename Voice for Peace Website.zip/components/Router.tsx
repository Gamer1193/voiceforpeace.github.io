import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

// Import all page components
import HomePage from '../pages/HomePage';
import AboutPage from '../pages/AboutPage';
import ProgramsPage from '../pages/ProgramsPage';
import EventsPage from '../pages/EventsPage';
import BlogPage from '../pages/BlogPage';
import VolunteerPage from '../pages/VolunteerPage';
import ResourcesPage from '../pages/ResourcesPage';
import ContactPage from '../pages/ContactPage';

export type PageType = 'home' | 'about' | 'programs' | 'events' | 'blog' | 'volunteer' | 'resources' | 'contact';

interface RouterProps {
  currentPage: PageType;
  setCurrentPage: (page: PageType) => void;
}

export default function Router({ currentPage, setCurrentPage }: RouterProps) {
  const [isLoading, setIsLoading] = useState(false);

  const pages = {
    home: HomePage,
    about: AboutPage,
    programs: ProgramsPage,
    events: EventsPage,
    blog: BlogPage,
    volunteer: VolunteerPage,
    resources: ResourcesPage,
    contact: ContactPage,
  };

  const CurrentPageComponent = pages[currentPage];

  const handlePageChange = (newPage: PageType) => {
    if (newPage !== currentPage) {
      setIsLoading(true);
      setTimeout(() => {
        setCurrentPage(newPage);
        setIsLoading(false);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 300);
    }
  };

  useEffect(() => {
    // Update URL without causing page reload (for demo purposes)
    const url = currentPage === 'home' ? '/' : `/${currentPage}`;
    window.history.replaceState({}, '', url);
  }, [currentPage]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-white to-[color:var(--peace-blue-50)]">
        <div className="text-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-16 h-16 border-4 border-[color:var(--peace-blue-200)] border-t-[color:var(--peace-blue-600)] rounded-full mx-auto mb-4"
          />
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-[color:var(--peace-blue-600)] font-medium"
          >
            Loading...
          </motion.p>
        </div>
      </div>
    );
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={currentPage}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
      >
        <CurrentPageComponent onNavigate={handlePageChange} />
      </motion.div>
    </AnimatePresence>
  );
}