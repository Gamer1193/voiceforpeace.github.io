import { motion } from 'motion/react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  icon: LucideIcon;
  label: string;
  value: string;
  color: string;
  index: number;
}

export default function StatCard({ 
  icon: Icon, 
  label, 
  value, 
  color, 
  index 
}: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0, rotateY: 90 }}
      animate={{ opacity: 1, scale: 1, rotateY: 0 }}
      transition={{ 
        duration: 0.8, 
        delay: index * 0.1,
        type: "spring",
        stiffness: 100
      }}
      whileHover={{ 
        scale: 1.1, 
        rotateY: 10,
        rotateX: 10,
        z: 30
      }}
      className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-3d border border-[color:var(--peace-blue-200)] preserve-3d perspective-500"
    >
      <div className="flex items-center justify-center w-14 h-14 bg-[color:var(--peace-blue-100)] rounded-full mb-4 mx-auto">
        <Icon className={`w-7 h-7 ${color}`} />
      </div>
      <motion.div 
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        className="text-3xl font-bold text-slate-900 mb-2"
      >
        {value}
      </motion.div>
      <div className="text-slate-600 font-medium">{label}</div>
    </motion.div>
  );
}