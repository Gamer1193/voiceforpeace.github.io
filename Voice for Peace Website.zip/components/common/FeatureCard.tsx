import { motion } from 'motion/react';
import { Card, CardContent } from '../ui/card';
import { LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  color: string;
  iconColor: string;
  index: number;
}

export default function FeatureCard({ 
  icon: Icon, 
  title, 
  description, 
  color, 
  iconColor, 
  index 
}: FeatureCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50, rotateX: 45 }}
      whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
      viewport={{ once: true }}
      transition={{ 
        duration: 0.8, 
        delay: index * 0.2,
        type: "spring",
        stiffness: 100
      }}
      whileHover={{ 
        scale: 1.05,
        rotateY: 15,
        rotateX: 15,
        z: 50
      }}
      className="group preserve-3d"
    >
      <Card className="h-full border-0 shadow-3d hover:shadow-3d-hover transition-all duration-500 bg-white/90 backdrop-blur-sm overflow-hidden perspective-500">
        <CardContent className="p-8 text-center">
          <motion.div 
            whileHover={{ rotateY: 360 }}
            transition={{ duration: 0.8 }}
            className={`w-20 h-20 bg-gradient-to-br ${color} rounded-2xl flex items-center justify-center mb-6 mx-auto preserve-3d`}
          >
            <Icon className={`w-10 h-10 ${iconColor}`} />
          </motion.div>
          <h3 className="text-xl font-bold text-slate-900 mb-4 group-hover:text-[color:var(--peace-blue-700)] transition-colors duration-300">
            {title}
          </h3>
          <p className="text-slate-600 leading-relaxed">
            {description}
          </p>
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: '60%' }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: index * 0.2 + 0.5 }}
            className="h-1 bg-gradient-to-r from-[color:var(--peace-blue-400)] to-[color:var(--peace-blue-600)] rounded-full mx-auto mt-6"
          />
        </CardContent>
      </Card>
    </motion.div>
  );
}