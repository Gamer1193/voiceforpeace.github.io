import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Calendar, MapPin, Users, Clock, ArrowRight, Star } from 'lucide-react';
import { PageType } from '../components/Router';
import { EVENTS } from '../data/constants';

interface EventsPageProps {
  onNavigate: (page: PageType) => void;
}

export default function EventsPage({ onNavigate }: EventsPageProps) {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-white via-[color:var(--peace-blue-50)] to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Badge className="mb-6 bg-[color:var(--peace-blue-100)] text-[color:var(--peace-blue-800)]">
              Upcoming Events • Join Us
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6">
              Peace{' '}
              <span className="text-gradient">Events</span>
            </h1>
            <p className="text-xl text-slate-600 mb-12 max-w-3xl mx-auto">
              Connect with like-minded individuals and expand your knowledge at our upcoming events.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Events Grid */}
      <section className="py-20 bg-gradient-to-b from-white to-[color:var(--peace-blue-50)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {EVENTS.map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                whileHover={{ scale: 1.05, rotateY: 10 }}
                className="preserve-3d"
              >
                <Card className="h-full shadow-3d hover:shadow-3d-hover transition-all duration-500 bg-white/90 backdrop-blur-sm relative">
                  {event.featured && (
                    <div className="absolute top-4 right-4 z-10">
                      <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
                        <Star className="w-4 h-4 mr-1" />
                        Featured
                      </Badge>
                    </div>
                  )}
                  <CardHeader>
                    <Badge className="w-fit mb-4 bg-[color:var(--peace-blue-100)] text-[color:var(--peace-blue-800)]">
                      {event.type}
                    </Badge>
                    <CardTitle className="text-xl font-bold text-slate-900 mb-2">
                      {event.title}
                    </CardTitle>
                    <p className="text-slate-600">{event.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 mb-6">
                      <div className="flex items-center text-slate-600">
                        <Calendar className="w-5 h-5 mr-3 text-[color:var(--peace-blue-600)]" />
                        <span>{event.date}</span>
                      </div>
                      <div className="flex items-center text-slate-600">
                        <Clock className="w-5 h-5 mr-3 text-[color:var(--peace-blue-600)]" />
                        <span>{event.time}</span>
                      </div>
                      <div className="flex items-center text-slate-600">
                        <MapPin className="w-5 h-5 mr-3 text-[color:var(--peace-blue-600)]" />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center text-slate-600">
                        <Users className="w-5 h-5 mr-3 text-[color:var(--peace-blue-600)]" />
                        <span>{event.attendees}</span>
                      </div>
                    </div>
                    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                      <Button className="w-full bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300">
                        Register Now
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-br from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            whileHover={{ scale: 1.02 }}
            className="preserve-3d"
          >
            <motion.div
              animate={{ y: [-5, 5, -5] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              <Calendar className="w-16 h-16 text-white mx-auto mb-6" />
            </motion.div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Don't Miss{' '}
              <span className="text-blue-200">Out</span>
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Stay connected with our peace-building community. Sign up for event notifications 
              and be the first to know about upcoming opportunities.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <motion.div 
                whileHover={{ scale: 1.05, rotateX: 5 }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  size="lg" 
                  onClick={() => onNavigate('volunteer')}
                  className="bg-white text-[color:var(--peace-blue-600)] hover:bg-blue-50 px-10 py-6 text-lg rounded-full shadow-xl hover:shadow-2xl transition-all duration-300"
                >
                  Join Our Community
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </motion.div>
              <motion.div 
                whileHover={{ scale: 1.05, rotateX: -5 }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  variant="outline" 
                  size="lg" 
                  onClick={() => onNavigate('contact')}
                  className="border-2 border-white/30 text-white hover:bg-white/10 px-10 py-6 text-lg rounded-full"
                >
                  Contact Us
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}