import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { 
  Heart, 
  BookOpen, 
  Users, 
  TreePine, 
  GraduationCap,
  Handshake,
  Globe,
  Target,
  ArrowRight,
  Calendar,
  MapPin,
  CheckCircle
} from 'lucide-react';
import { PageType } from '../components/Router';

interface ProgramsPageProps {
  onNavigate: (page: PageType) => void;
}

export default function ProgramsPage({ onNavigate }: ProgramsPageProps) {
  const programs = [
    {
      id: 1,
      title: 'Peace Education Initiative',
      description: 'Comprehensive educational programs that teach conflict resolution, empathy, and peaceful communication in schools and communities.',
      image: 'https://images.unsplash.com/photo-1544717297-fa95b6ee9643?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      icon: BookOpen,
      participants: '25,000+ students',
      locations: '150+ schools',
      duration: 'Ongoing',
      impact: '95% conflict reduction',
      features: [
        'Curriculum development for peace education',
        'Teacher training and certification',
        'Student leadership workshops',
        'Community dialogue sessions',
        'Digital learning platforms'
      ],
      color: 'from-blue-500 to-indigo-600'
    },
    {
      id: 2,
      title: 'Community Healing Centers',
      description: 'Safe spaces where communities affected by conflict can come together for healing, reconciliation, and building sustainable peace.',
      image: 'https://images.unsplash.com/photo-1559027615-cd4628902d4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      icon: Heart,
      participants: '15,000+ people served',
      locations: '75+ centers worldwide',
      duration: 'Year-round',
      impact: '88% success rate',
      features: [
        'Trauma counseling and therapy',
        'Mediation and reconciliation',
        'Community support groups',
        'Cultural healing ceremonies',
        'Family reunification programs'
      ],
      color: 'from-red-500 to-pink-600'
    },
    {
      id: 3,
      title: 'Youth Leadership Program',
      description: 'Empowering the next generation of peace leaders through mentorship, training, and opportunities to lead positive change.',
      image: 'https://images.unsplash.com/photo-1529390079861-591de354faf5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      icon: Users,
      participants: '5,000+ youth trained',
      locations: '200+ communities',
      duration: '18-month program',
      impact: '92% leadership retention',
      features: [
        'Leadership skills development',
        'Peace advocacy training',
        'Mentorship programs',
        'Youth-led community projects',
        'International exchange programs'
      ],
      color: 'from-green-500 to-emerald-600'
    },
    {
      id: 4,
      title: 'Environmental Peacebuilding',
      description: 'Addressing environmental challenges that contribute to conflict while promoting sustainable practices that unite communities.',
      image: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      icon: TreePine,
      participants: '50,000+ beneficiaries',
      locations: '100+ projects',
      duration: 'Multi-year initiatives',
      impact: '75% resource conflict reduction',
      features: [
        'Sustainable agriculture programs',
        'Water resource management',
        'Renewable energy initiatives',
        'Environmental conflict resolution',
        'Climate adaptation planning'
      ],
      color: 'from-teal-500 to-cyan-600'
    },
    {
      id: 5,
      title: 'Women\'s Peace Network',
      description: 'Supporting women as key agents of change in peacebuilding processes and community leadership roles.',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      icon: Handshake,
      participants: '10,000+ women empowered',
      locations: '60+ countries',
      duration: 'Ongoing',
      impact: '85% leadership positions filled',
      features: [
        'Women\'s leadership training',
        'Economic empowerment programs',
        'Political participation support',
        'Conflict mediation training',
        'Network building initiatives'
      ],
      color: 'from-purple-500 to-violet-600'
    },
    {
      id: 6,
      title: 'Digital Peace Platform',
      description: 'Leveraging technology to connect peace advocates globally and provide digital tools for conflict resolution.',
      image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      icon: Globe,
      participants: '100,000+ users',
      locations: 'Global reach',
      duration: '24/7 availability',
      impact: '95% user satisfaction',
      features: [
        'Online mediation tools',
        'Virtual peace education',
        'Global networking platform',
        'Conflict early warning system',
        'AI-powered peace insights'
      ],
      color: 'from-orange-500 to-amber-600'
    }
  ];

  const stats = [
    { label: 'Active Programs', value: '500+', icon: Target },
    { label: 'Countries Reached', value: '75+', icon: Globe },
    { label: 'People Impacted', value: '250K+', icon: Users },
    { label: 'Success Rate', value: '94%', icon: CheckCircle }
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-white via-[color:var(--peace-blue-50)] to-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <Badge className="mb-6 bg-[color:var(--peace-blue-100)] text-[color:var(--peace-blue-800)] hover:bg-[color:var(--peace-blue-200)]">
              6 Core Programs • Global Impact
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6 leading-tight">
              Our{' '}
              <span className="text-gradient">Programs</span>
              <br />
              Building Peace Worldwide
            </h1>
            <p className="text-xl text-slate-600 mb-12 max-w-4xl mx-auto leading-relaxed">
              From education and healing to youth empowerment and environmental action, 
              our comprehensive programs address the root causes of conflict while building 
              sustainable foundations for peace.
            </p>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto mb-12">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0, rotateY: 90 }}
                    animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                    transition={{ 
                      duration: 0.8, 
                      delay: index * 0.1,
                      type: "spring",
                      stiffness: 100
                    }}
                    whileHover={{ 
                      scale: 1.1, 
                      rotateY: 10,
                      z: 30
                    }}
                    className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-3d border border-[color:var(--peace-blue-200)] preserve-3d"
                  >
                    <div className="flex items-center justify-center w-12 h-12 bg-[color:var(--peace-blue-100)] rounded-full mb-3 mx-auto">
                      <Icon className="w-6 h-6 text-[color:var(--peace-blue-600)]" />
                    </div>
                    <motion.div 
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                      className="text-2xl font-bold text-slate-900 mb-1"
                    >
                      {stat.value}
                    </motion.div>
                    <div className="text-sm text-slate-600">{stat.label}</div>
                  </motion.div>
                );
              })}
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  size="lg" 
                  onClick={() => onNavigate('volunteer')}
                  className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white px-8 py-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  Join a Program
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  variant="outline" 
                  size="lg" 
                  onClick={() => onNavigate('contact')}
                  className="border-2 border-[color:var(--peace-blue-600)] text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)] px-8 py-4 rounded-full"
                >
                  Learn More
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Programs Grid */}
      <section className="py-20 bg-gradient-to-b from-white to-[color:var(--peace-blue-50)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {programs.map((program, index) => {
              const Icon = program.icon;
              return (
                <motion.div
                  key={program.id}
                  initial={{ opacity: 0, y: 50, rotateX: 45 }}
                  whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                  viewport={{ once: true }}
                  transition={{ 
                    duration: 0.8, 
                    delay: index * 0.1,
                    type: "spring",
                    stiffness: 100
                  }}
                  whileHover={{ 
                    scale: 1.02,
                    rotateY: 5,
                    z: 20
                  }}
                  className="group preserve-3d"
                >
                  <Card className="h-full border-0 shadow-3d hover:shadow-3d-hover transition-all duration-500 bg-white/90 backdrop-blur-sm overflow-hidden">
                    <div className="relative h-64 overflow-hidden">
                      <ImageWithFallback
                        src={program.image}
                        alt={program.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                      <motion.div
                        whileHover={{ scale: 1.1, rotate: 360 }}
                        transition={{ duration: 0.6 }}
                        className={`absolute top-4 right-4 w-16 h-16 bg-gradient-to-br ${program.color} rounded-full flex items-center justify-center shadow-lg preserve-3d`}
                      >
                        <Icon className="w-8 h-8 text-white" />
                      </motion.div>
                      <div className="absolute bottom-4 left-4 right-4">
                        <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-blue-200 transition-colors duration-300">
                          {program.title}
                        </h3>
                      </div>
                    </div>

                    <CardContent className="p-8">
                      <p className="text-slate-600 mb-6 leading-relaxed">
                        {program.description}
                      </p>

                      {/* Stats */}
                      <div className="grid grid-cols-2 gap-4 mb-6">
                        <div className="bg-[color:var(--peace-blue-50)] rounded-lg p-4 text-center">
                          <div className="text-lg font-bold text-[color:var(--peace-blue-700)]">{program.participants}</div>
                          <div className="text-xs text-slate-600">Participants</div>
                        </div>
                        <div className="bg-[color:var(--peace-blue-50)] rounded-lg p-4 text-center">
                          <div className="text-lg font-bold text-[color:var(--peace-blue-700)]">{program.locations}</div>
                          <div className="text-xs text-slate-600">Locations</div>
                        </div>
                        <div className="bg-[color:var(--peace-blue-50)] rounded-lg p-4 text-center">
                          <div className="text-lg font-bold text-[color:var(--peace-blue-700)]">{program.duration}</div>
                          <div className="text-xs text-slate-600">Duration</div>
                        </div>
                        <div className="bg-[color:var(--peace-blue-50)] rounded-lg p-4 text-center">
                          <div className="text-lg font-bold text-[color:var(--peace-blue-700)]">{program.impact}</div>
                          <div className="text-xs text-slate-600">Impact</div>
                        </div>
                      </div>

                      {/* Features */}
                      <div className="mb-6">
                        <h4 className="font-semibold text-slate-900 mb-3">Key Features:</h4>
                        <ul className="space-y-2">
                          {program.features.map((feature, featureIndex) => (
                            <motion.li
                              key={featureIndex}
                              initial={{ opacity: 0, x: -20 }}
                              whileInView={{ opacity: 1, x: 0 }}
                              viewport={{ once: true }}
                              transition={{ delay: featureIndex * 0.1 }}
                              className="flex items-center text-sm text-slate-600"
                            >
                              <CheckCircle className="w-4 h-4 text-[color:var(--peace-blue-500)] mr-3 flex-shrink-0" />
                              {feature}
                            </motion.li>
                          ))}
                        </ul>
                      </div>

                      <div className="flex items-center justify-between">
                        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                          <Button 
                            onClick={() => onNavigate('volunteer')}
                            className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                          >
                            Get Involved
                            <ArrowRight className="w-4 h-4 ml-2" />
                          </Button>
                        </motion.div>
                        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                          <Button 
                            variant="outline"
                            onClick={() => onNavigate('contact')}
                            className="border-[color:var(--peace-blue-600)] text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)] px-6 py-3 rounded-full"
                          >
                            Learn More
                          </Button>
                        </motion.div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-br from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            whileHover={{ scale: 1.02 }}
            className="preserve-3d"
          >
            <motion.div
              animate={{ y: [-5, 5, -5] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              <GraduationCap className="w-16 h-16 text-white mx-auto mb-6" />
            </motion.div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Ready to{' '}
              <span className="text-blue-200">Get Started</span>?
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Choose a program that aligns with your passion and skills. Every contribution 
              makes a difference in building a more peaceful world.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <motion.div 
                whileHover={{ scale: 1.05, rotateX: 5 }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  size="lg" 
                  onClick={() => onNavigate('volunteer')}
                  className="bg-white text-[color:var(--peace-blue-600)] hover:bg-blue-50 px-10 py-6 text-lg rounded-full shadow-xl hover:shadow-2xl transition-all duration-300"
                >
                  Apply to Join
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </motion.div>
              <motion.div 
                whileHover={{ scale: 1.05, rotateX: -5 }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  variant="outline" 
                  size="lg" 
                  onClick={() => onNavigate('contact')}
                  className="border-2 border-white/30 text-white hover:bg-white/10 px-10 py-6 text-lg rounded-full"
                >
                  Contact Us
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}