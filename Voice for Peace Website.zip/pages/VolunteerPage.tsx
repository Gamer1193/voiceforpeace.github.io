import { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { Badge } from '../components/ui/badge';
import { Heart, Users, ArrowRight, CheckCircle, Send, MapPin, Clock } from 'lucide-react';
import { VOLUNTEER_OPPORTUNITIES } from '../data/constants';
import { PageType } from '../components/Router';

interface VolunteerPageProps {
  onNavigate: (page: PageType) => void;
}

export default function VolunteerPage({ onNavigate }: VolunteerPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    interests: '',
    experience: '',
    availability: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-white via-[color:var(--peace-blue-50)] to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Badge className="mb-6 bg-[color:var(--peace-blue-100)] text-[color:var(--peace-blue-800)]">
              Make a Difference • Join Our Team
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6">
              Volunteer for{' '}
              <span className="text-gradient">Peace</span>
            </h1>
            <p className="text-xl text-slate-600 mb-12 max-w-3xl mx-auto">
              Join our global community of volunteers working to create positive change. 
              Every skill, every hour, every heart makes a difference.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Opportunities Grid */}
      <section className="py-20 bg-gradient-to-b from-white to-[color:var(--peace-blue-50)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              Current{' '}
              <span className="text-gradient">Opportunities</span>
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Find the perfect volunteer role that matches your skills and passion.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {VOLUNTEER_OPPORTUNITIES.map((opportunity, index) => (
              <motion.div
                key={opportunity.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                whileHover={{ scale: 1.05, rotateY: 10 }}
                className="preserve-3d"
              >
                <Card className="h-full shadow-3d hover:shadow-3d-hover transition-all duration-500 bg-white/90 backdrop-blur-sm">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-4">
                      <Badge 
                        className={`${
                          opportunity.urgency === 'High' 
                            ? 'bg-red-100 text-red-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {opportunity.urgency} Priority
                      </Badge>
                    </div>
                    <CardTitle className="text-xl font-bold text-slate-900 mb-2">
                      {opportunity.title}
                    </CardTitle>
                    <p className="text-slate-600">{opportunity.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 mb-6">
                      <div className="flex items-center text-slate-600">
                        <MapPin className="w-5 h-5 mr-3 text-[color:var(--peace-blue-600)]" />
                        <span>{opportunity.location}</span>
                      </div>
                      <div className="flex items-center text-slate-600">
                        <Clock className="w-5 h-5 mr-3 text-[color:var(--peace-blue-600)]" />
                        <span>{opportunity.timeCommitment}</span>
                      </div>
                    </div>
                    <div className="mb-6">
                      <h4 className="font-semibold text-slate-900 mb-3">Required Skills:</h4>
                      <div className="flex flex-wrap gap-2">
                        {opportunity.skills.map((skill, skillIndex) => (
                          <Badge key={skillIndex} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <Button className="w-full bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white rounded-full">
                      Apply Now
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section className="py-20 bg-gradient-to-b from-[color:var(--peace-blue-50)] to-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              Join Our{' '}
              <span className="text-gradient">Team</span>
            </h2>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto">
              Ready to make a difference? Fill out our volunteer application form.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <Card className="shadow-3d border-0 bg-white/90 backdrop-blur-sm">
              <CardContent className="p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        name="name"
                        placeholder="Enter your full name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="Enter your email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="interests">Areas of Interest</Label>
                    <Textarea
                      id="interests"
                      name="interests"
                      placeholder="Which volunteer opportunities interest you most?"
                      value={formData.interests}
                      onChange={handleInputChange}
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="experience">Relevant Experience</Label>
                    <Textarea
                      id="experience"
                      name="experience"
                      placeholder="Tell us about your relevant experience or skills"
                      value={formData.experience}
                      onChange={handleInputChange}
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="availability">Availability</Label>
                    <Textarea
                      id="availability"
                      name="availability"
                      placeholder="When are you available to volunteer?"
                      value={formData.availability}
                      onChange={handleInputChange}
                      rows={2}
                    />
                  </div>

                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white py-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                    >
                      Submit Application
                      <Send className="w-5 h-5 ml-2" />
                    </Button>
                  </motion.div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>
    </div>
  );
}