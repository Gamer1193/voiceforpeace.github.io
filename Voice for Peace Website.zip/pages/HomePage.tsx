import { motion } from 'motion/react';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { ArrowRight, Sparkles, MessageCircle } from 'lucide-react';
import { PageType } from '../components/Router';
import { STATS, FEATURES, TESTIMONIALS } from '../data/constants';
import StatCard from '../components/common/StatCard';
import FeatureCard from '../components/common/FeatureCard';

interface HomePageProps {
  onNavigate: (page: PageType) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="min-h-screen">
      {/* Hero Section with 3D Elements */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-white via-[color:var(--peace-blue-50)] to-white">
        {/* Animated 3D Background Elements */}
        <div className="absolute inset-0 perspective-1000">
          <motion.div
            animate={{ 
              rotateY: [0, 360],
              rotateX: [0, 45, 0],
              scale: [1, 1.2, 1]
            }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-br from-[color:var(--peace-blue-200)] to-[color:var(--peace-blue-300)] rounded-full opacity-30 preserve-3d"
          />
          <motion.div
            animate={{ 
              rotateZ: [0, 360],
              y: [-20, 20, -20],
              scale: [0.8, 1.1, 0.8]
            }}
            transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
            className="absolute top-1/2 right-20 w-24 h-24 bg-gradient-to-br from-[color:var(--peace-blue-300)] to-[color:var(--peace-blue-400)] transform rotate-45 opacity-40"
          />
          <motion.div
            animate={{ 
              rotateX: [0, 180, 360],
              x: [-30, 30, -30],
              y: [0, -40, 0]
            }}
            transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
            className="absolute bottom-32 left-1/4 w-16 h-16 bg-gradient-to-br from-[color:var(--peace-blue-400)] to-[color:var(--peace-blue-500)] rounded-lg opacity-25 preserve-3d"
          />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="text-center"
          >
            {/* Floating Badge */}
            <motion.div 
              animate={{ y: [-5, 5, -5] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="inline-flex items-center space-x-2 bg-gradient-to-r from-[color:var(--peace-blue-100)] to-[color:var(--peace-blue-200)] text-[color:var(--peace-blue-800)] px-6 py-3 rounded-full mb-8 shadow-lg"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              >
                <Sparkles className="w-5 h-5" />
              </motion.div>
              <span className="font-medium">Building a Better Tomorrow Together</span>
            </motion.div>
            
            {/* 3D Animated Title */}
            <motion.h1 
              initial={{ opacity: 0, scale: 0.8, rotateX: 90 }}
              animate={{ opacity: 1, scale: 1, rotateX: 0 }}
              transition={{ duration: 1.2, ease: "easeOut", delay: 0.3 }}
              className="text-5xl md:text-7xl lg:text-8xl font-bold text-slate-900 mb-8 leading-tight preserve-3d"
            >
              Together, Our{' '}
              <motion.span 
                animate={{ 
                  backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                }}
                transition={{ duration: 3, repeat: Infinity }}
                className="bg-gradient-to-r from-[color:var(--peace-blue-600)] via-[color:var(--peace-blue-700)] to-[color:var(--peace-blue-600)] bg-[length:200%_100%] bg-clip-text text-transparent"
              >
                Voices
              </motion.span>{' '}
              <br className="hidden sm:block" />
              Can Change the{' '}
              <motion.span 
                animate={{ rotateY: [0, 10, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="inline-block bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-800)] bg-clip-text text-transparent preserve-3d"
              >
                World
              </motion.span>
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="text-xl md:text-2xl text-slate-600 mb-12 max-w-4xl mx-auto leading-relaxed"
            >
              Join a global movement dedicated to fostering peace, understanding, and positive change. 
              Every voice matters, every action counts, and together we can build a more harmonious world.
            </motion.p>

            {/* 3D Action Buttons */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.9 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-16"
            >
              <motion.div 
                whileHover={{ 
                  scale: 1.05, 
                  rotateX: 5,
                  rotateY: 5,
                  z: 20
                }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  size="lg" 
                  onClick={() => onNavigate('volunteer')}
                  className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] hover:from-[color:var(--peace-blue-700)] hover:to-[color:var(--peace-blue-800)] text-white px-10 py-6 text-xl rounded-full shadow-xl hover:shadow-2xl transition-all duration-300"
                >
                  <span>Join the Movement</span>
                  <ArrowRight className="w-6 h-6 ml-2" />
                </Button>
              </motion.div>
              
              <motion.div 
                whileHover={{ 
                  scale: 1.05,
                  rotateX: -5,
                  rotateY: -5
                }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  variant="outline" 
                  size="lg" 
                  onClick={() => onNavigate('about')}
                  className="border-2 border-[color:var(--peace-blue-600)] text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)] px-10 py-6 text-xl rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  Learn More
                </Button>
              </motion.div>
            </motion.div>

            {/* 3D Statistics Cards */}
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 1.2 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto"
            >
              {STATS.map((stat, index) => (
                <StatCard key={index} {...stat} index={index} />
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Features Section with 3D Cards */}
      <section className="py-20 bg-gradient-to-b from-white to-[color:var(--peace-blue-50)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              Our{' '}
              <span className="text-gradient">Impact Areas</span>
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              We focus on four key areas to create lasting peace and positive change in communities worldwide.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {FEATURES.map((feature, index) => (
              <FeatureCard key={index} {...feature} index={index} />
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="text-center mt-16"
          >
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button 
                size="lg" 
                onClick={() => onNavigate('programs')}
                className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white px-8 py-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
              >
                Explore All Programs
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Testimonials Section with 3D Effect */}
      <section className="py-20 bg-gradient-to-br from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Voices of{' '}
              <span className="text-blue-200">Change</span>
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Hear from the people whose lives have been transformed by our peace-building initiatives.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50, rotateY: 45 }}
                whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
                viewport={{ once: true }}
                transition={{ 
                  duration: 0.8, 
                  delay: index * 0.2,
                  type: "spring",
                  stiffness: 100
                }}
                whileHover={{ 
                  scale: 1.05,
                  rotateY: 10,
                  z: 30
                }}
                className="preserve-3d"
              >
                <Card className="h-full bg-white/10 backdrop-blur-sm border border-white/20 shadow-xl hover:shadow-2xl transition-all duration-500">
                  <CardContent className="p-8">
                    <motion.div
                      animate={{ rotate: [0, 5, -5, 0] }}
                      transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                      className="w-16 h-16 rounded-full overflow-hidden mb-6 mx-auto border-4 border-white/30"
                    >
                      <ImageWithFallback
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="w-full h-full object-cover"
                      />
                    </motion.div>
                    <blockquote className="text-lg text-blue-50 mb-6 italic leading-relaxed">
                      "{testimonial.content}"
                    </blockquote>
                    <div className="text-center">
                      <div className="font-semibold text-white">{testimonial.name}</div>
                      <div className="text-blue-200 text-sm">{testimonial.role}</div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action with 3D Elements */}
      <section className="py-20 bg-gradient-to-b from-[color:var(--peace-blue-50)] to-white relative overflow-hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="bg-white/80 backdrop-blur-sm rounded-3xl p-12 shadow-3d border border-[color:var(--peace-blue-200)]"
          >
            <motion.div
              animate={{ y: [-5, 5, -5] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              <MessageCircle className="w-16 h-16 text-[color:var(--peace-blue-600)] mx-auto mb-6" />
            </motion.div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              Ready to Make a{' '}
              <span className="text-gradient">Difference</span>?
            </h2>
            <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
              Join thousands of peace advocates working to create positive change. 
              Your voice, your actions, your impact - it all starts today.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <motion.div 
                whileHover={{ scale: 1.05, rotateX: 5 }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  size="lg" 
                  onClick={() => onNavigate('volunteer')}
                  className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white px-10 py-6 text-lg rounded-full shadow-xl hover:shadow-2xl transition-all duration-300"
                >
                  Start Your Journey
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </motion.div>
              <motion.div 
                whileHover={{ scale: 1.05, rotateX: -5 }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  variant="outline" 
                  size="lg" 
                  onClick={() => onNavigate('contact')}
                  className="border-2 border-[color:var(--peace-blue-600)] text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)] px-10 py-6 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  Get in Touch
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}