import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Download, ExternalLink, BookOpen, Video, FileText, Headphones } from 'lucide-react';
import { PageType } from '../components/Router';

interface ResourcesPageProps {
  onNavigate: (page: PageType) => void;
}

const RESOURCE_CATEGORIES = [
  {
    title: 'Educational Materials',
    icon: BookOpen,
    resources: [
      { name: 'Peace Education Curriculum', type: 'PDF', size: '2.5 MB' },
      { name: 'Conflict Resolution Guide', type: 'PDF', size: '1.8 MB' },
      { name: 'Community Dialogue Toolkit', type: 'PDF', size: '3.2 MB' }
    ]
  },
  {
    title: 'Video Training',
    icon: Video,
    resources: [
      { name: 'Mediation Techniques Workshop', type: 'Video', size: '45 min' },
      { name: 'Youth Leadership Training', type: 'Video', size: '32 min' },
      { name: 'Environmental Peacebuilding', type: 'Video', size: '28 min' }
    ]
  },
  {
    title: 'Research Papers',
    icon: FileText,
    resources: [
      { name: 'Global Peace Index 2024', type: 'PDF', size: '4.1 MB' },
      { name: 'Technology in Conflict Prevention', type: 'PDF', size: '2.9 MB' },
      { name: 'Women in Peacebuilding', type: 'PDF', size: '3.5 MB' }
    ]
  },
  {
    title: 'Podcasts',
    icon: Headphones,
    resources: [
      { name: 'Voices of Peace Series', type: 'Audio', size: '12 episodes' },
      { name: 'Youth Changemakers', type: 'Audio', size: '8 episodes' },
      { name: 'Community Stories', type: 'Audio', size: '15 episodes' }
    ]
  }
];

export default function ResourcesPage({ onNavigate }: ResourcesPageProps) {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-white via-[color:var(--peace-blue-50)] to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Badge className="mb-6 bg-[color:var(--peace-blue-100)] text-[color:var(--peace-blue-800)]">
              Knowledge Hub • Free Resources
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6">
              Peace{' '}
              <span className="text-gradient">Resources</span>
            </h1>
            <p className="text-xl text-slate-600 mb-12 max-w-3xl mx-auto">
              Access our comprehensive library of educational materials, training videos, 
              research papers, and tools for peacebuilding.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Resources Grid */}
      <section className="py-20 bg-gradient-to-b from-white to-[color:var(--peace-blue-50)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {RESOURCE_CATEGORIES.map((category, index) => {
              const Icon = category.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: index * 0.2 }}
                  whileHover={{ scale: 1.02, rotateY: 5 }}
                  className="preserve-3d"
                >
                  <Card className="h-full shadow-3d hover:shadow-3d-hover transition-all duration-500 bg-white/90 backdrop-blur-sm">
                    <CardHeader>
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-[color:var(--peace-blue-100)] rounded-full flex items-center justify-center mr-4">
                          <Icon className="w-6 h-6 text-[color:var(--peace-blue-600)]" />
                        </div>
                        <CardTitle className="text-2xl font-bold text-slate-900">
                          {category.title}
                        </CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {category.resources.map((resource, resourceIndex) => (
                          <motion.div
                            key={resourceIndex}
                            initial={{ opacity: 0, x: -20 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: resourceIndex * 0.1 }}
                            whileHover={{ x: 5 }}
                            className="flex items-center justify-between p-4 bg-[color:var(--peace-blue-50)] rounded-lg hover:bg-[color:var(--peace-blue-100)] transition-colors duration-300"
                          >
                            <div>
                              <h4 className="font-semibold text-slate-900">{resource.name}</h4>
                              <p className="text-sm text-slate-600">{resource.type} • {resource.size}</p>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Button size="sm" variant="ghost" className="text-[color:var(--peace-blue-600)]">
                                <Download className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="ghost" className="text-[color:var(--peace-blue-600)]">
                                <ExternalLink className="w-4 h-4" />
                              </Button>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}