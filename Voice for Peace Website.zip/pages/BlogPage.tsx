import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Calendar, User, Clock, ArrowRight, BookOpen } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { PageType } from '../components/Router';
import { BLOG_POSTS } from '../data/constants';

interface BlogPageProps {
  onNavigate: (page: PageType) => void;
}

export default function BlogPage({ onNavigate }: BlogPageProps) {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-white via-[color:var(--peace-blue-50)] to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Badge className="mb-6 bg-[color:var(--peace-blue-100)] text-[color:var(--peace-blue-800)]">
              Latest Insights • Peace Blog
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6">
              Peace{' '}
              <span className="text-gradient">Insights</span>
            </h1>
            <p className="text-xl text-slate-600 mb-12 max-w-3xl mx-auto">
              Thoughts, research, and stories from the frontlines of peacebuilding around the world.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-20 bg-gradient-to-b from-white to-[color:var(--peace-blue-50)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {BLOG_POSTS.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                whileHover={{ scale: 1.05, rotateY: 10 }}
                className="preserve-3d"
              >
                <Card className="h-full shadow-3d hover:shadow-3d-hover transition-all duration-500 bg-white/90 backdrop-blur-sm overflow-hidden">
                  <div className="relative h-48 overflow-hidden">
                    <ImageWithFallback
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                    />
                    {post.featured && (
                      <Badge className="absolute top-4 left-4 bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
                        Featured
                      </Badge>
                    )}
                    <Badge className="absolute top-4 right-4 bg-[color:var(--peace-blue-600)] text-white">
                      {post.category}
                    </Badge>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-xl font-bold text-slate-900 line-clamp-2">
                      {post.title}
                    </CardTitle>
                    <p className="text-slate-600 line-clamp-3">{post.excerpt}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm text-slate-500 mb-4">
                      <div className="flex items-center">
                        <User className="w-4 h-4 mr-2" />
                        <span>{post.author}</span>
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2" />
                        <span>{post.readTime}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-sm text-slate-500">
                        <Calendar className="w-4 h-4 mr-2" />
                        <span>{post.date}</span>
                      </div>
                      <Button variant="ghost" className="text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)]">
                        Read More
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-br from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            whileHover={{ scale: 1.02 }}
            className="preserve-3d"
          >
            <motion.div
              animate={{ y: [-5, 5, -5] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              <BookOpen className="w-16 h-16 text-white mx-auto mb-6" />
            </motion.div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Stay{' '}
              <span className="text-blue-200">Informed</span>
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Subscribe to our newsletter for the latest insights on peacebuilding, 
              conflict resolution, and positive change around the world.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <motion.div 
                whileHover={{ scale: 1.05, rotateX: 5 }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  size="lg" 
                  onClick={() => onNavigate('contact')}
                  className="bg-white text-[color:var(--peace-blue-600)] hover:bg-blue-50 px-10 py-6 text-lg rounded-full shadow-xl hover:shadow-2xl transition-all duration-300"
                >
                  Subscribe Now
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </motion.div>
              <motion.div 
                whileHover={{ scale: 1.05, rotateX: -5 }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  variant="outline" 
                  size="lg" 
                  onClick={() => onNavigate('about')}
                  className="border-2 border-white/30 text-white hover:bg-white/10 px-10 py-6 text-lg rounded-full"
                >
                  Learn More
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}