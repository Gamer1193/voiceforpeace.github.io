import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { 
  Users, 
  Globe, 
  Target, 
  Award, 
  Heart,
  Lightbulb,
  Shield,
  Handshake,
  ArrowRight,
  CheckCircle,
  Star,
  TrendingUp
} from 'lucide-react';
import { PageType } from '../components/Router';

interface AboutPageProps {
  onNavigate: (page: PageType) => void;
}

export default function AboutPage({ onNavigate }: AboutPageProps) {
  const values = [
    {
      icon: Heart,
      title: 'Compassion',
      description: 'We approach every situation with empathy and understanding, recognizing the humanity in all people.',
      color: 'from-red-500 to-pink-500'
    },
    {
      icon: Handshake,
      title: 'Unity',
      description: 'We believe that diverse perspectives strengthen our mission and create more effective solutions.',
      color: 'from-blue-500 to-indigo-500'
    },
    {
      icon: Shield,
      title: 'Integrity',
      description: 'We maintain the highest ethical standards in all our actions and remain transparent in our work.',
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: Lightbulb,
      title: 'Innovation',
      description: 'We continuously seek creative and effective approaches to peacebuilding and conflict resolution.',
      color: 'from-yellow-500 to-orange-500'
    }
  ];

  const timeline = [
    {
      year: '2018',
      title: 'Foundation',
      description: 'Voice for Peace was founded by a group of passionate peace advocates.',
      achievement: 'First community healing program launched'
    },
    {
      year: '2019',
      title: 'Expansion',
      description: 'Extended our reach to 10 countries and established youth leadership programs.',
      achievement: '5,000+ people impacted'
    },
    {
      year: '2020',
      title: 'Digital Innovation',
      description: 'Adapted to global challenges by launching virtual peace education platforms.',
      achievement: 'Reached 50+ countries virtually'
    },
    {
      year: '2021',
      title: 'Recognition',
      description: 'Received UN Peace Ambassador recognition for outstanding contributions.',
      achievement: 'First major international award'
    },
    {
      year: '2022',
      title: 'Scale',
      description: 'Established permanent offices on three continents and hired 100+ staff.',
      achievement: '100,000+ lives impacted'
    },
    {
      year: '2023',
      title: 'Impact',
      description: 'Launched environmental peacebuilding initiatives and AI-powered solutions.',
      achievement: '200,000+ lives impacted'
    },
    {
      year: '2024',
      title: 'Global Leader',
      description: 'Became a leading voice in international peace policy and conflict prevention.',
      achievement: '250,000+ lives impacted'
    }
  ];

  const team = [
    {
      name: 'Dr. Sarah Mitchell',
      role: 'Founder & CEO',
      bio: 'Former UN mediator with 20+ years experience in conflict resolution.',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80',
      specialties: ['Conflict Resolution', 'International Relations', 'Policy Development']
    },
    {
      name: 'Marcus Johnson',
      role: 'Director of Programs',
      bio: 'Community organizer and peace educator specializing in youth development.',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80',
      specialties: ['Youth Leadership', 'Community Organizing', 'Program Development']
    },
    {
      name: 'Dr. Amina Hassan',
      role: 'Head of Research',
      bio: 'Peace studies researcher focusing on innovative conflict prevention methods.',
      image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80',
      specialties: ['Peace Research', 'Data Analysis', 'Innovation Strategy']
    },
    {
      name: 'Carlos Rodriguez',
      role: 'Regional Director',
      bio: 'Former diplomat with expertise in Latin American peace processes.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80',
      specialties: ['Diplomacy', 'Regional Development', 'Cultural Mediation']
    }
  ];

  const achievements = [
    { icon: Users, label: 'Lives Transformed', value: '250,000+', progress: 85 },
    { icon: Globe, label: 'Countries Reached', value: '75+', progress: 92 },
    { icon: Target, label: 'Programs Active', value: '500+', progress: 78 },
    { icon: Award, label: 'Recognition Awards', value: '25+', progress: 95 }
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-white via-[color:var(--peace-blue-50)] to-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Badge className="mb-6 bg-[color:var(--peace-blue-100)] text-[color:var(--peace-blue-800)] hover:bg-[color:var(--peace-blue-200)]">
                Est. 2018 • 6 Years of Impact
              </Badge>
              <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6 leading-tight">
                Building Bridges to{' '}
                <span className="text-gradient">Lasting Peace</span>
              </h1>
              <p className="text-xl text-slate-600 mb-8 leading-relaxed">
                We are a global movement of peace advocates, researchers, and community leaders 
                working together to create sustainable solutions to conflict and build more 
                harmonious communities worldwide.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button 
                    size="lg" 
                    onClick={() => onNavigate('programs')}
                    className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white px-8 py-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    Our Programs
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button 
                    variant="outline" 
                    size="lg" 
                    onClick={() => onNavigate('contact')}
                    className="border-2 border-[color:var(--peace-blue-600)] text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)] px-8 py-4 rounded-full"
                  >
                    Get in Touch
                  </Button>
                </motion.div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50, rotateY: 45 }}
              animate={{ opacity: 1, x: 0, rotateY: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
              whileHover={{ rotateY: 10, scale: 1.02 }}
              className="preserve-3d"
            >
              <div className="relative">
                <motion.div
                  animate={{ y: [-10, 10, -10] }}
                  transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-br from-[color:var(--peace-blue-400)] to-[color:var(--peace-blue-500)] rounded-full opacity-20 animate-pulse"
                />
                <motion.div
                  animate={{ y: [10, -10, 10] }}
                  transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -bottom-8 -left-8 w-32 h-32 bg-gradient-to-br from-[color:var(--peace-blue-300)] to-[color:var(--peace-blue-400)] rounded-full opacity-15 animate-pulse"
                />
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1559027615-cd4628902d4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                  alt="Team collaboration"
                  className="w-full h-96 object-cover rounded-3xl shadow-3d"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-gradient-to-b from-white to-[color:var(--peace-blue-50)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              Our{' '}
              <span className="text-gradient">Purpose</span>
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Driven by a clear mission and an inspiring vision for the future.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -50, rotateY: 45 }}
              whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              whileHover={{ scale: 1.02, rotateY: 5 }}
              className="preserve-3d"
            >
              <Card className="h-full shadow-3d border-0 bg-gradient-to-br from-white to-[color:var(--peace-blue-50)]">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-to-br from-[color:var(--peace-blue-500)] to-[color:var(--peace-blue-600)] rounded-2xl flex items-center justify-center mb-4">
                    <Target className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl text-slate-900">Our Mission</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-lg text-slate-600 leading-relaxed">
                    To foster sustainable peace through education, dialogue, and community engagement. 
                    We work to address the root causes of conflict while building the skills and 
                    relationships necessary for lasting harmony.
                  </p>
                  <div className="mt-6 space-y-3">
                    {['Community Healing', 'Peace Education', 'Conflict Resolution', 'Youth Empowerment'].map((item, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center"
                      >
                        <CheckCircle className="w-5 h-5 text-[color:var(--peace-blue-600)] mr-3" />
                        <span className="text-slate-700">{item}</span>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50, rotateY: -45 }}
              whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              whileHover={{ scale: 1.02, rotateY: -5 }}
              className="preserve-3d"
            >
              <Card className="h-full shadow-3d border-0 bg-gradient-to-br from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white">
                <CardHeader>
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-4">
                    <Star className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl text-white">Our Vision</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-lg text-blue-100 leading-relaxed">
                    A world where conflicts are resolved through understanding and dialogue, 
                    where communities are empowered to create their own solutions, and where 
                    peace is not just the absence of conflict, but the presence of justice and opportunity.
                  </p>
                  <div className="mt-6 space-y-3">
                    {['Global Harmony', 'Justice for All', 'Sustainable Solutions', 'Empowered Communities'].map((item, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.1 + 0.2 }}
                        className="flex items-center"
                      >
                        <Star className="w-5 h-5 text-blue-200 mr-3" />
                        <span className="text-blue-100">{item}</span>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values Section with 3D Cards */}
      <section className="py-20 bg-gradient-to-b from-[color:var(--peace-blue-50)] to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              Our{' '}
              <span className="text-gradient">Values</span>
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              The principles that guide everything we do and shape our approach to building peace.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50, rotateX: 45 }}
                  whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                  viewport={{ once: true }}
                  transition={{ 
                    duration: 0.8, 
                    delay: index * 0.1,
                    type: "spring",
                    stiffness: 100
                  }}
                  whileHover={{ 
                    scale: 1.05,
                    rotateY: 15,
                    rotateX: 15,
                    z: 50
                  }}
                  className="group preserve-3d"
                >
                  <Card className="h-full border-0 shadow-3d hover:shadow-3d-hover transition-all duration-500 bg-white/90 backdrop-blur-sm">
                    <CardContent className="p-8 text-center">
                      <motion.div 
                        whileHover={{ rotateY: 360, scale: 1.1 }}
                        transition={{ duration: 0.8 }}
                        className={`w-20 h-20 bg-gradient-to-br ${value.color} rounded-2xl flex items-center justify-center mb-6 mx-auto preserve-3d shadow-lg`}
                      >
                        <Icon className="w-10 h-10 text-white" />
                      </motion.div>
                      <h3 className="text-xl font-bold text-slate-900 mb-4 group-hover:text-[color:var(--peace-blue-700)] transition-colors duration-300">
                        {value.title}
                      </h3>
                      <p className="text-slate-600 leading-relaxed">
                        {value.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20 bg-gradient-to-br from-slate-900 to-slate-800 text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Our{' '}
              <span className="text-blue-400">Journey</span>
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              From humble beginnings to global impact - see how we've grown and evolved.
            </p>
          </motion.div>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-gradient-to-b from-blue-500 to-purple-500"></div>

            <div className="space-y-12">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  className={`relative flex items-center ${
                    index % 2 === 0 ? 'justify-start' : 'justify-end'
                  }`}
                >
                  <motion.div
                    whileHover={{ scale: 1.02, rotateY: index % 2 === 0 ? 10 : -10 }}
                    className={`w-full max-w-md ${
                      index % 2 === 0 ? 'mr-8' : 'ml-8'
                    } preserve-3d`}
                  >
                    <Card className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 shadow-3d">
                      <CardContent className="p-6">
                        <div className={`flex items-center mb-4 ${
                          index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                        }`}>
                          <Badge className="bg-blue-600 text-white px-4 py-2 text-lg font-bold">
                            {item.year}
                          </Badge>
                        </div>
                        <h3 className="text-xl font-bold text-white mb-3">{item.title}</h3>
                        <p className="text-slate-300 mb-4 leading-relaxed">{item.description}</p>
                        <div className="flex items-center text-blue-400">
                          <TrendingUp className="w-4 h-4 mr-2" />
                          <span className="text-sm font-medium">{item.achievement}</span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  {/* Timeline dot */}
                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 + 0.3, type: "spring", stiffness: 200 }}
                    whileHover={{ scale: 1.5 }}
                    className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full border-4 border-slate-900 z-10"
                  />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gradient-to-b from-white to-[color:var(--peace-blue-50)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              Meet Our{' '}
              <span className="text-gradient">Leadership</span>
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Experienced leaders from diverse backgrounds united by a common vision for peace.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50, rotateY: 45 }}
                whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
                viewport={{ once: true }}
                transition={{ 
                  duration: 0.8, 
                  delay: index * 0.1,
                  type: "spring",
                  stiffness: 100
                }}
                whileHover={{ 
                  scale: 1.05,
                  rotateY: 10,
                  z: 30
                }}
                className="group preserve-3d"
              >
                <Card className="h-full border-0 shadow-3d hover:shadow-3d-hover transition-all duration-500 bg-white/90 backdrop-blur-sm overflow-hidden">
                  <CardContent className="p-6 text-center">
                    <motion.div
                      whileHover={{ scale: 1.1, rotateZ: 5 }}
                      className="w-24 h-24 rounded-full overflow-hidden mb-6 mx-auto border-4 border-[color:var(--peace-blue-200)] shadow-lg"
                    >
                      <ImageWithFallback
                        src={member.image}
                        alt={member.name}
                        className="w-full h-full object-cover"
                      />
                    </motion.div>
                    <h3 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-[color:var(--peace-blue-700)] transition-colors duration-300">
                      {member.name}
                    </h3>
                    <p className="text-[color:var(--peace-blue-600)] font-medium mb-4">{member.role}</p>
                    <p className="text-slate-600 text-sm mb-4 leading-relaxed">{member.bio}</p>
                    <div className="flex flex-wrap gap-2 justify-center">
                      {member.specialties.map((specialty, specIndex) => (
                        <Badge key={specIndex} variant="secondary" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="py-20 bg-gradient-to-br from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Our{' '}
              <span className="text-blue-200">Impact</span>
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Measurable results that demonstrate our commitment to creating lasting change.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => {
              const Icon = achievement.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0, rotateY: 90 }}
                  whileInView={{ opacity: 1, scale: 1, rotateY: 0 }}
                  viewport={{ once: true }}
                  transition={{ 
                    duration: 0.8, 
                    delay: index * 0.1,
                    type: "spring",
                    stiffness: 100
                  }}
                  whileHover={{ 
                    scale: 1.1,
                    rotateY: 15,
                    z: 30
                  }}
                  className="preserve-3d"
                >
                  <Card className="bg-white/10 backdrop-blur-sm border border-white/20 shadow-3d hover:shadow-3d-hover transition-all duration-500">
                    <CardContent className="p-8 text-center">
                      <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <motion.div 
                        animate={{ scale: [1, 1.1, 1] }}
                        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                        className="text-3xl font-bold text-white mb-2"
                      >
                        {achievement.value}
                      </motion.div>
                      <div className="text-blue-200 font-medium mb-4">{achievement.label}</div>
                      <div className="w-full bg-white/20 rounded-full h-2">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${achievement.progress}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1.5, delay: index * 0.2 }}
                          className="bg-white h-2 rounded-full"
                        />
                      </div>
                      <div className="text-blue-100 text-sm mt-2">{achievement.progress}% of goal</div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-b from-[color:var(--peace-blue-50)] to-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            whileHover={{ scale: 1.02 }}
            className="bg-white/80 backdrop-blur-sm rounded-3xl p-12 shadow-3d border border-[color:var(--peace-blue-200)] preserve-3d"
          >
            <motion.div
              animate={{ y: [-5, 5, -5] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              <Heart className="w-16 h-16 text-[color:var(--peace-blue-600)] mx-auto mb-6" />
            </motion.div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              Join Our{' '}
              <span className="text-gradient">Mission</span>
            </h2>
            <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
              Whether you're an individual looking to make a difference or an organization 
              seeking partnership, there are many ways to support our work for peace.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <motion.div 
                whileHover={{ scale: 1.05, rotateX: 5 }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  size="lg" 
                  onClick={() => onNavigate('volunteer')}
                  className="bg-gradient-to-r from-[color:var(--peace-blue-600)] to-[color:var(--peace-blue-700)] text-white px-10 py-6 text-lg rounded-full shadow-xl hover:shadow-2xl transition-all duration-300"
                >
                  Get Involved
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </motion.div>
              <motion.div 
                whileHover={{ scale: 1.05, rotateX: -5 }} 
                whileTap={{ scale: 0.95 }}
                className="preserve-3d"
              >
                <Button 
                  variant="outline" 
                  size="lg" 
                  onClick={() => onNavigate('contact')}
                  className="border-2 border-[color:var(--peace-blue-600)] text-[color:var(--peace-blue-600)] hover:bg-[color:var(--peace-blue-50)] px-10 py-6 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  Contact Us
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}